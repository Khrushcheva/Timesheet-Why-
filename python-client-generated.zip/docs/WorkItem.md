# WorkItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_id** | **int** |  | 
**work_type_id** | **int** |  | 
**start_date_time** | **str** |  | 
**end_date_time** | **str** |  | 
**duration** | **float** |  | 
**value** | **str** |  | 
**description** | **str** |  | 
**documents** | **str** |  | 
**hour_price** | **int** |  | 
**work_price** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



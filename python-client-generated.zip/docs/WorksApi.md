# swagger_client.WorksApi

All URIs are relative to *https://virtserver.swaggerhub.com/TimesheetWhy/Works/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**search_work**](WorksApi.md#search_work) | **GET** /work | get all Works


# **search_work**
> list[WorkItem] search_work(limit=limit)

get all Works

By passing in the appropriate options, you can search for available inventory in the system 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.WorksApi()
limit = 56 # int | WorkType with this id in the system (optional)

try:
    # get all Works
    api_response = api_instance.search_work(limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling WorksApi->search_work: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| WorkType with this id in the system | [optional] 

### Return type

[**list[WorkItem]**](WorkItem.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


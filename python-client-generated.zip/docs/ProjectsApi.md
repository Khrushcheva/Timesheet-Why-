# swagger_client.ProjectsApi

All URIs are relative to *https://virtserver.swaggerhub.com/TimesheetWhy/Works/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_project**](ProjectsApi.md#add_project) | **POST** /project | adds a project
[**search_project**](ProjectsApi.md#search_project) | **GET** /project | get all projects


# **add_project**
> add_project(project_item=project_item)

adds a project

Adds an item to the system

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ProjectsApi()
project_item = swagger_client.ProjectItem() # ProjectItem | Project item to add (optional)

try:
    # adds a project
    api_instance.add_project(project_item=project_item)
except ApiException as e:
    print("Exception when calling ProjectsApi->add_project: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **project_item** | [**ProjectItem**](ProjectItem.md)| Project item to add | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **search_project**
> list[ProjectItem] search_project(id=id)

get all projects

By passing in the appropriate options, you can search for available inventory in the system 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ProjectsApi()
id = 56 # int | project with this id in the system (optional)

try:
    # get all projects
    api_response = api_instance.search_project(id=id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProjectsApi->search_project: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| project with this id in the system | [optional] 

### Return type

[**list[ProjectItem]**](ProjectItem.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


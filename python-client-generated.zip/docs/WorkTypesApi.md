# swagger_client.WorkTypesApi

All URIs are relative to *https://virtserver.swaggerhub.com/TimesheetWhy/Works/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_work_type**](WorkTypesApi.md#add_work_type) | **POST** /worktype | adds a WorkType
[**search_work_type**](WorkTypesApi.md#search_work_type) | **GET** /worktype | get all WorkTypes


# **add_work_type**
> add_work_type(work_type_item=work_type_item)

adds a WorkType

Adds an item to the system

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.WorkTypesApi()
work_type_item = swagger_client.WorkTypeItem() # WorkTypeItem | WorkType item to add (optional)

try:
    # adds a WorkType
    api_instance.add_work_type(work_type_item=work_type_item)
except ApiException as e:
    print("Exception when calling WorkTypesApi->add_work_type: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **work_type_item** | [**WorkTypeItem**](WorkTypeItem.md)| WorkType item to add | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **search_work_type**
> list[WorkTypeItem] search_work_type(id=id)

get all WorkTypes

By passing in the appropriate options, you can search for available inventory in the system 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.WorkTypesApi()
id = 56 # int | WorkType with this id in the system (optional)

try:
    # get all WorkTypes
    api_response = api_instance.search_work_type(id=id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling WorkTypesApi->search_work_type: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| WorkType with this id in the system | [optional] 

### Return type

[**list[WorkTypeItem]**](WorkTypeItem.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


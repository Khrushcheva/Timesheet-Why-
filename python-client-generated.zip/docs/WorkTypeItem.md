# WorkTypeItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**work_type_name** | **str** |  | 
**work_type_description** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


